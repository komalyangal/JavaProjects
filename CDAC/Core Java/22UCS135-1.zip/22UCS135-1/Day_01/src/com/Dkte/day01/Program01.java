package com.Dkte.day01;

public class Program01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
	}

}
